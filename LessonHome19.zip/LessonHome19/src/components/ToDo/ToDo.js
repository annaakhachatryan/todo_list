import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectText, toggleToDo, resetText } from '../store/slice/ToDoTextSlice/ToDoTextSlice'
import { selectToDos, addToDo, deleteToDo, checkToDo } from '../store/slice/AddToDo/AddToDo'
import { fetchToDo } from '../store/slice/AddToDo/AddToDo.API'
import { selectUser } from '../store/slice/User/UserSlice'
import { userFetch } from '../store/slice/User/UserAPI'
import { editItem, selectEditItem } from '../store/slice/EditToDo/EditToDo'
import { Loading } from '../../Utils/Svg/Loading'

export const ToDo = () => {
    const text = useSelector(selectText)
    const { data, isLoading } = useSelector(selectToDos)
    const user = useSelector(selectUser)
    const editItems = useSelector(selectEditItem)
    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(fetchToDo())
        dispatch(userFetch())
    }, [])

    const handlerSubmitForm = (e) => {
        e.preventDefault()
        dispatch(addToDo(text))
        dispatch(resetText())
    }

    return (
        <div>
            <form onSubmit={handlerSubmitForm}>
                <input type='text'
                    onChange={(e) => dispatch(toggleToDo(e.target.value))}
                    value={text}
                    placeholder='TODO!'
                />
                <button>{editItems ? 'Edit' : 'Add'}</button>

            </form>

            {
                isLoading ? <div className='divLoading'>
                                <div className='loading'><Loading/></div>
                                <p>isLoading</p>
                            </div> :
                    data.length === 0 ? (<h3>There is no toDo!</h3>) :
                        (
                            data.map(toDo => (
                                <div className='box' key={toDo.id}>
                                    <div>
                                        <input className='checkbox'
                                            type='checkbox'
                                            checked={toDo.isCompleted}
                                            onChange={() => dispatch(checkToDo(toDo.id))}
                                        />
                                        <p className='text'
                                            style={{ textDecoration: toDo.isCompleted ? 'line-through' : 'none' }}
                                        > {toDo.text} </p>
                                        <button onClick={() => dispatch(deleteToDo(toDo.id))}>Delete</button>
                                        <button onClick={() => dispatch(editItem(toDo))}>Edit</button>
                                    </div>
                                </div>
                            ))
                        )
            }
        </div>
    )
}
