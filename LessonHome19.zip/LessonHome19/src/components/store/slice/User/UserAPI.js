import { createAsyncThunk } from "@reduxjs/toolkit";

export const userFetch = createAsyncThunk(
    'user/userFetch',
    async function(){
        const res = await fetch('https://jsonplaceholder.typicode.com/users')
        const jsonRes =  await res.json()
        return jsonRes
    }
)