import { createSlice } from "@reduxjs/toolkit";
import { userFetch } from "./UserAPI";

const userSlice = createSlice({
    name:'user',
    initialState:{},
    reducers:{

    },
    extraReducers:{
        [userFetch.pending] : (state, action) => {
            console.log('...pending');
        },
        [userFetch.fulfilled] : (state, {payload}) => {
            return payload
        },
        [userFetch.rejected] : (state, {payload}) => {
            console.log('...error');
        },
    }
})

export const selectUser = state => state.user

// export const {} = userSlice.actions 
export const userReducer = userSlice.reducer