import { createSlice } from "@reduxjs/toolkit";
import { fetchToDo } from "./AddToDo.API";

const addToDoSlice = createSlice({
    name: 'toDos',
    initialState: {
        data: [],
        isLoading: false,
    },
    reducers: {
        addToDo(state, { payload }) {
            state.data.push({
                id: new Date().getTime().toString(),
                text: payload,
                isCompleted: false,
            })
        },
        deleteToDo(state, { payload }) {
            state.data = [...state.data.filter(toDo => toDo.id !== payload)]
        },
        checkToDo(state, { payload }) {
            state.data = [...state.data.map(toDo => toDo.id === payload ? { ...toDo, isCompleted: !toDo.isCompleted } : toDo)]
        },
        editedToDoItems(state, { payload }) {
            state.data = [...state.data.map(toDo => toDo.id === payload.editId ? { ...toDo, text:payload.text } : toDo)]
        }
    },
    extraReducers: {
        [fetchToDo.pending]: (state, action) => {
            state.isLoading = true
        },
        [fetchToDo.fulfilled]: (state, { payload }) => {
            state.data = payload
            state.isLoading = false
        },
        [fetchToDo.rejected] : (state, {payload}) => {
            console.log('error');
        }
    }
})

export const selectToDos = state => state.toDos

export const { addToDo, deleteToDo, checkToDo, editedToDoItems} = addToDoSlice.actions
export const addToDoReducer = addToDoSlice.reducer

