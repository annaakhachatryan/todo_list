import { createAsyncThunk } from "@reduxjs/toolkit";

export const fetchToDo = createAsyncThunk(
    'toDos/fetchToDo',
    async function () {
        const res = await fetch('https://jsonplaceholder.typicode.com/todos')
        const jsonRes = await res.json()
        const data = [
            ...jsonRes.map(toDo => ({
                id: toDo.id,
                text: toDo.title.split(' ').slice(0, 4).join(' '),
                isCompleted: toDo.completed
            }))
        ]
        return data
    }
)