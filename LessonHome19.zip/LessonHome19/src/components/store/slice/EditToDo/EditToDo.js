import { createSlice } from "@reduxjs/toolkit"

const editItemSlice = createSlice({
    name:'editItem',
    initialState:null,
    reducers:{
        editItem(state, {payload}){
            return payload
        },
        resetEditItem(state, {payload}){
            return null
        }
    }
})

export const selectEditItem = state => state.editItem

export const {editItem, resetEditItem} = editItemSlice.actions
export const editItemReducer = editItemSlice.reducer