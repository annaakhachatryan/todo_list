import { configureStore } from "@reduxjs/toolkit";
import { textReducer } from "./slice/ToDoTextSlice/ToDoTextSlice";
import { addToDoReducer } from "./slice/AddToDo/AddToDo";
import { userReducer } from "./slice/User/UserSlice";
import { editItemReducer } from "./slice/EditToDo/EditToDo";
import { editingToDoItems } from "./middleWare/EditToDo/EditToDo";
import { editToDos, ignoreItems } from "./middleWare/ToDoMiddleware/ToDoMiddleWare";

const store = configureStore({
    reducer:{
        text:textReducer,
        toDos:addToDoReducer,
        user:userReducer,
        editItem:editItemReducer,
    },
    middleware:(getDefaultMiddleware) => [...getDefaultMiddleware(), editingToDoItems, ignoreItems, editToDos]
})

export default store