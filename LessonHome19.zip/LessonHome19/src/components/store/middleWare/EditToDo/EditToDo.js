import { toggleToDo } from "../../slice/ToDoTextSlice/ToDoTextSlice"

export const  editingToDoItems = (store) => (next ) => (action) =>{
    if(action.type === 'editItem/editItem'){
        store.dispatch(toggleToDo(action.payload.text))
    }
    next(action)
}