import { resetEditItem } from "../../slice/EditToDo/EditToDo";

export const ignoreItems = (store) => (next) => (action) =>{
    if(action.type === 'toDos/addToDo' && !action.payload.trim()){
        return
    }
    next(action)
}


export const editToDos = (store) => (next) => (action) => {
    if(action.type === 'toDos/addToDo' && store.getState().editItem){
        action.type = 'toDos/editedToDoItems'
        action.payload = {
            editId : store.getState().editItem.id,
            text : action.payload
        }
        store.dispatch(resetEditItem())
    }
    next(action)
}
